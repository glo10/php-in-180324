<?php

// TODO Traitez la connexion depuis une soumission du formulaire de connexion côté front
echo 'OK sign in';// ce echo est à supprimer et remplacer par votre traitement